/* ═══════════════════════════════════════════════════════════════
   VICE HEIST — main menu logic
   No dependencies, no build step.

   Integration contract (see README.md):
     • window event  "viceheist:splash-complete"  — fired once by the splash; the menu reveals itself on it.
     • window event  "viceheist:menu-action"      — fired for quick-play / create-lobby / join-lobby.
         detail = { action, ...payload }. Call event.preventDefault() to claim it (start the match).
         Unclaimed actions show an honest "lobbies open soon" notice — nothing is faked.
     • window event  "viceheist:settings-changed" — detail = full settings object.
     • localStorage  "viceheist.settings" / "viceheist.lobby"
   ═══════════════════════════════════════════════════════════════ */
(() => {
  'use strict';

  const SETTINGS_KEY = 'viceheist.settings';
  const LOBBY_KEY = 'viceheist.lobby';
  const PLAYERS_MIN = 4;
  const PLAYERS_MAX = 10;
  const SPLASH_MIN_MS = 1900;
  const SPLASH_MAX_MS = 6000;

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const root = document.documentElement;
  const app = $('#app');

  /* ───────── persistence ───────── */
  const load = (key, defaults) => {
    try { return { ...defaults, ...JSON.parse(localStorage.getItem(key) || '{}') }; }
    catch { return { ...defaults }; }
  };
  const save = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* private mode */ } };

  const settings = load(SETTINGS_KEY, {
    master: 80, music: 50, sfx: 80,
    gfx: 'high',
    reducedMotion: matchMedia('(prefers-reduced-motion: reduce)').matches,
    hand: 'right',
  });
  const lobby = load(LOBBY_KEY, { map: 'ocean-drive-estate', maxPlayers: 6, visibility: 'private' });
  lobby.maxPlayers = Math.min(PLAYERS_MAX, Math.max(PLAYERS_MIN, lobby.maxPlayers | 0 || 6));

  /* ───────── images: Netlify Image CDN when hosted, plain files otherwise ───────── */
  const img = (file, width) => {
    const el = new Image();
    el.alt = '';
    el.draggable = false;
    el.onerror = () => { el.onerror = null; el.src = `img/${file}`; };
    el.src = location.protocol.startsWith('http') ? `/.netlify/images?url=/img/${file}&w=${width}&fm=webp` : `img/${file}`;
    return el;
  };

  /* ───────── audio: tiny synth so the volume sliders are real ───────── */
  const audio = (() => {
    let ctx, master, music, sfx, timer, step = 0;
    const CHORDS = [[220, 261.63, 329.63, 392], [174.61, 220, 261.63, 329.63], [196, 246.94, 293.66, 369.99], [164.81, 207.65, 246.94, 329.63]];

    const apply = () => {
      if (!ctx) return;
      const t = ctx.currentTime;
      master.gain.setTargetAtTime(settings.master / 100, t, .05);
      music.gain.setTargetAtTime((settings.music / 100) * .5, t, .05);
      sfx.gain.setTargetAtTime(settings.sfx / 100, t, .05);
    };

    const chord = () => {
      if (!ctx || ctx.state !== 'running') return;
      const t = ctx.currentTime;
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass'; lp.frequency.value = 900; lp.Q.value = .4;
      lp.connect(music);
      CHORDS[step++ % CHORDS.length].forEach((f, i) => {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.type = i % 2 ? 'triangle' : 'sawtooth';
        o.frequency.value = f / 2;
        o.detune.value = (i - 1.5) * 6;
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(.085, t + 1.6);
        g.gain.setValueAtTime(.085, t + 4.2);
        g.gain.linearRampToValueAtTime(0, t + 7);
        o.connect(g).connect(lp);
        o.start(t); o.stop(t + 7.1);
      });
    };

    const start = () => {
      if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      ctx = new AC();
      master = ctx.createGain(); music = ctx.createGain(); sfx = ctx.createGain();
      music.connect(master); sfx.connect(master); master.connect(ctx.destination);
      master.gain.value = settings.master / 100;
      music.gain.value = (settings.music / 100) * .5;
      sfx.gain.value = settings.sfx / 100;
      chord();
      timer = setInterval(chord, 5600);
    };

    const tone = (from, to, dur, type = 'sine', vol = .22, delay = 0) => {
      if (!ctx) return;
      const t = ctx.currentTime + delay;
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = type;
      o.frequency.setValueAtTime(from, t);
      o.frequency.exponentialRampToValueAtTime(to, t + dur);
      g.gain.setValueAtTime(vol, t);
      g.gain.exponentialRampToValueAtTime(.001, t + dur);
      o.connect(g).connect(sfx);
      o.start(t); o.stop(t + dur + .02);
    };

    const play = (name) => {
      start();
      if (name === 'play') { tone(440, 660, .09, 'triangle', .28); tone(660, 990, .14, 'triangle', .28, .08); tone(990, 1320, .22, 'triangle', .22, .17); }
      else if (name === 'back') tone(520, 330, .1, 'sine', .22);
      else if (name === 'deny') { tone(220, 180, .12, 'square', .1); tone(200, 150, .16, 'square', .1, .1); }
      else if (name === 'tick') tone(880, 900, .03, 'sine', .12);
      else if (name === 'hop') tone(500, 900, .12, 'sine', .18);
      else tone(620, 880, .07, 'triangle', .22);
    };

    document.addEventListener('visibilitychange', () => {
      if (!ctx) return;
      if (document.hidden) ctx.suspend(); else ctx.resume();
    });

    return { start, play, apply, stop: () => clearInterval(timer) };
  })();

  /* ───────── toast ───────── */
  const toastEl = $('#toast');
  let toastTimer;
  const toast = (msg) => {
    toastEl.textContent = msg;
    toastEl.classList.add('is-on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('is-on'), 2600);
  };

  /* ───────── screens ───────── */
  const screens = Object.fromEntries($$('.screen').map((el) => [el.dataset.name, el]));
  const stack = ['main'];
  const show = (name) => {
    Object.entries(screens).forEach(([key, el]) => {
      const on = key === name;
      el.classList.toggle('is-active', on);
      el.inert = !on;
    });
    app.dataset.screen = name;
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
  };
  const go = (name) => { if (screens[name] && stack.at(-1) !== name) { stack.push(name); show(name); } };
  const back = () => { if (stack.length > 1) { stack.pop(); show(stack.at(-1)); audio.play('back'); } };

  /* ───────── game actions (the real hand-off to the game client) ───────── */
  const act = (action, payload = {}) => {
    const event = new CustomEvent('viceheist:menu-action', { detail: { action, ...payload }, cancelable: true });
    const claimed = !window.dispatchEvent(event);
    if (!claimed) toast('The crew is assembling… lobbies open soon.');
    return claimed;
  };

  /* ───────── settings ───────── */
  const applySettings = () => {
    root.dataset.gfx = settings.gfx;
    root.dataset.motion = settings.reducedMotion ? 'reduced' : 'full';
    $$('.pad').forEach((p) => { p.dataset.hand = settings.hand; });
    $('#padSettings').setAttribute('aria-label', settings.hand === 'left' ? 'Action button left, thumbstick right' : 'Thumbstick left, action button right');
    audio.apply();
  };
  const commitSettings = () => {
    save(SETTINGS_KEY, settings);
    applySettings();
    window.dispatchEvent(new CustomEvent('viceheist:settings-changed', { detail: { ...settings } }));
  };

  $$('input[type="range"][data-setting]').forEach((input) => {
    const out = input.parentElement.querySelector('output');
    const paint = () => { input.style.setProperty('--v', `${input.value}%`); out.textContent = input.value; };
    input.value = settings[input.dataset.setting];
    paint();
    input.addEventListener('input', () => { settings[input.dataset.setting] = +input.value; paint(); audio.start(); audio.apply(); });
    input.addEventListener('change', () => { commitSettings(); audio.play(input.dataset.setting === 'music' ? 'tick' : 'tap'); });
  });

  const bindSeg = (seg, read, write) => {
    const paint = () => $$('.btn', seg).forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.value === read())));
    seg.addEventListener('click', (e) => {
      const b = e.target.closest('.btn');
      if (!b || b.dataset.value === read()) return;
      write(b.dataset.value); paint(); audio.play('tap');
    });
    paint();
    return paint;
  };
  $$('.seg[data-setting]').forEach((seg) => bindSeg(seg, () => settings[seg.dataset.setting], (v) => { settings[seg.dataset.setting] = v; commitSettings(); }));

  $$('[data-setting-switch]').forEach((sw) => {
    const key = sw.dataset.settingSwitch;
    const paint = () => sw.setAttribute('aria-checked', String(!!settings[key]));
    sw.addEventListener('click', () => { settings[key] = !settings[key]; paint(); commitSettings(); audio.play('tap'); });
    paint();
  });

  /* fullscreen — only offered where the browser really supports it */
  const fsSwitch = $('#fullscreenSwitch');
  const fsRequest = root.requestFullscreen || root.webkitRequestFullscreen;
  const fsExit = document.exitFullscreen || document.webkitExitFullscreen;
  const fsActive = () => !!(document.fullscreenElement || document.webkitFullscreenElement);
  if (!fsRequest || !fsExit) $('#fullscreenRow').remove();
  else {
    const paint = () => fsSwitch.setAttribute('aria-checked', String(fsActive()));
    fsSwitch.addEventListener('click', async () => {
      audio.play('tap');
      try { await (fsActive() ? fsExit.call(document) : fsRequest.call(root)); }
      catch { toast('Fullscreen is blocked by this browser.'); }
      paint();
    });
    document.addEventListener('fullscreenchange', paint);
    document.addEventListener('webkitfullscreenchange', paint);
  }

  /* ───────── custom game ───────── */
  const playersOut = $('#playersOut'), down = $('#playersDown'), up = $('#playersUp'), visHint = $('#visHint');
  const paintLobby = () => {
    playersOut.textContent = lobby.maxPlayers;
    down.disabled = lobby.maxPlayers <= PLAYERS_MIN;
    up.disabled = lobby.maxPlayers >= PLAYERS_MAX;
    visHint.textContent = lobby.visibility === 'private' ? 'Invite only, by room code' : 'Anyone can drop in';
  };
  const stepPlayers = (d) => {
    lobby.maxPlayers = Math.min(PLAYERS_MAX, Math.max(PLAYERS_MIN, lobby.maxPlayers + d));
    save(LOBBY_KEY, lobby); paintLobby(); audio.play('tick');
  };
  down.addEventListener('click', () => stepPlayers(-1));
  up.addEventListener('click', () => stepPlayers(1));
  const paintVisibility = bindSeg($('.seg[data-lobby="visibility"]'), () => lobby.visibility, (v) => { lobby.visibility = v; save(LOBBY_KEY, lobby); paintLobby(); });
  paintLobby();

  /* ───────── join by code ───────── */
  const codeInput = $('#joinCode');
  codeInput.addEventListener('input', () => { codeInput.value = codeInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4); });
  $('#joinForm').addEventListener('submit', (e) => {
    e.preventDefault();
    if (codeInput.value.length !== 4) {
      codeInput.classList.remove('shake'); void codeInput.offsetWidth; codeInput.classList.add('shake');
      setTimeout(() => codeInput.classList.remove('shake'), 400);
      audio.play('deny');
      toast('Room codes are 4 characters.');
      return;
    }
    codeInput.blur();
    audio.play('play');
    act('join-lobby', { code: codeInput.value });
  });

  /* ───────── delegated clicks ───────── */
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-go], [data-back], [data-action], [data-action-go]');
    if (!b) return;
    if ('back' in b.dataset) return back();
    audio.play(b.dataset.sfx || 'tap');
    if (b.dataset.go) return go(b.dataset.go);
    if (b.dataset.actionGo === 'create') {           // Play → Create Lobby = host a private match
      lobby.visibility = 'private'; save(LOBBY_KEY, lobby); paintVisibility(); paintLobby();
      return go('custom');
    }
    if (b.dataset.action === 'quick-play') return act('quick-play');
    if (b.dataset.action === 'create-lobby') return act('create-lobby', { ...lobby });
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') back(); });
  document.addEventListener('pointerdown', () => audio.start(), { once: true });

  /* ───────── crew showcase ───────── */
  const CREW = [
    { c: 'purple', k: .88, t: 3.1, d: -.4, lean: -1 },
    { c: 'red',    k: .96, t: 2.6, d: -1.2, lean: 1 },
    { c: 'teal',   k: 1.1, t: 2.9, d: -.2, lean: 0, z: 3 },
    { c: 'gold',   k: 1,   t: 2.4, d: -1.7, lean: -1, z: 2 },
    { c: 'blue',   k: .94, t: 3.3, d: -.9, lean: 1 },
    { c: 'pink',   k: .86, t: 2.7, d: -2.1, lean: -1 },
  ];
  const crewEl = $('#crew');
  CREW.forEach((m, i) => {
    const el = document.createElement('div');
    el.className = 'thief';
    el.style.cssText = `--k:${m.k};--t:${m.t}s;--d:${m.d}s;--lean:${m.lean}deg;--z:${m.z || 1};--tilt:${i % 2 ? 5 : -5}deg`;
    el.append(img(`crew-${m.c}.png`, 360));
    el.addEventListener('pointerdown', () => {
      el.classList.remove('hop'); void el.offsetWidth; el.classList.add('hop');
      audio.play('hop');
    });
    el.addEventListener('animationend', (e) => { if (e.animationName === 'hop') el.classList.remove('hop'); });
    crewEl.append(el);
  });
  $$('img[data-crew]').forEach((el) => {
    const src = img(`crew-${el.dataset.crew}.png`, 240);
    el.onerror = () => { el.onerror = null; el.src = `img/crew-${el.dataset.crew}.png`; };
    el.src = src.src;
  });

  /* ───────── ambient light motes ───────── */
  const motes = $('#motes');
  const COLORS = ['#ff3d9a', '#4ff0dc', '#ffd166', '#ff8a4c'];
  for (let i = 0; i < 14; i++) {
    const m = document.createElement('i');
    m.style.cssText = `left:${(i * 37 + 9) % 100}%;--d:${.5 + (i % 3) * .3}rem;--c:${COLORS[i % 4]};--t:${13 + (i * 7) % 11}s;--delay:${-((i * 5) % 17)}s;--x:${((i % 5) - 2) * 6}rem`;
    motes.append(m);
  }

  /* ───────── connection status (the browser's real network state) ───────── */
  const net = $('#net');
  const paintNet = () => {
    net.classList.toggle('is-offline', !navigator.onLine);
    net.lastElementChild.textContent = navigator.onLine ? 'Online' : 'Offline';
  };
  addEventListener('online', paintNet); addEventListener('offline', paintNet); paintNet();

  /* ───────── keep the browser from scrolling / zooming the menu ───────── */
  ['gesturestart', 'gesturechange'].forEach((t) => document.addEventListener(t, (e) => e.preventDefault(), { passive: false }));
  document.addEventListener('touchmove', (e) => {
    if (e.touches.length > 1 || !e.target.closest('.panel-body, input[type="range"]')) e.preventDefault();
  }, { passive: false });
  document.addEventListener('contextmenu', (e) => { if (!e.target.closest('input')) e.preventDefault(); });

  /* ───────── splash → menu ───────── */
  applySettings();

  window.addEventListener('viceheist:splash-complete', () => {
    $('#splash').classList.add('is-done');
    app.classList.add('is-ready');
    $('#stage').inert = false;
    show('main');
  }, { once: true });

  // The splash: wait for the artwork and fonts, then hand over exactly once.
  (() => {
    const fill = $('#loadFill');
    const scene = $('#sceneImg');
    const wait = (ms) => new Promise((r) => setTimeout(r, ms));
    const sceneReady = new Promise((r) => {
      const check = () => { if (scene.complete && scene.naturalWidth) r(); };
      scene.addEventListener('load', check); check();
    });
    const fontsReady = document.fonts ? document.fonts.ready : Promise.resolve();
    let done = 0;
    const tick = () => { done += 1; fill.style.transform = `scaleX(${Math.min(1, .1 + done * .3)})`; };
    const steps = [sceneReady, fontsReady, wait(SPLASH_MIN_MS)].map((p) => p.then(tick));
    requestAnimationFrame(() => { fill.style.transform = 'scaleX(.1)'; });
    Promise.race([Promise.all(steps), wait(SPLASH_MAX_MS)])
      .then(() => { fill.style.transform = 'scaleX(1)'; return wait(450); })
      .then(() => window.dispatchEvent(new CustomEvent('viceheist:splash-complete')));
  })();
})();
