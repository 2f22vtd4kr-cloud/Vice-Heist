# Vice Heist — Main Menu

The main menu for **Vice Heist** ("A crew of thieves. One rat."): a neon-noir, Miami-at-dusk game menu that takes over as soon as the splash screen finishes. It is designed mobile-first and fits a phone screen in portrait or landscape without scrolling.

## What's in it

- **Splash → menu hand-off** – the splash loads the artwork and fonts, then fires one event and fades into the menu.
- **Main menu** – Vice Heist logo, the six-thief crew with idle animations (tap one to make it hop), a large PLAY button and Custom Game / How to Play / Settings / Credits.
- **Play** – Quick Play, Create Lobby and Join Lobby (4-character room code).
- **Custom Game** – map (Ocean Drive Estate), crew size (4–10) and private/public lobby.
- **Settings** – master / music / effects volume, graphics quality, fullscreen (where the browser supports it), reduce motion and left/right-handed touch layout. Saved in the browser.
- **How to Play** and **Credits** (which also holds the zip download).

## Technology

Plain HTML, CSS and JavaScript — no framework, no dependencies, no build step. Fonts are self-hosted (`fonts/`), artwork lives in `img/`, sound is synthesised with the Web Audio API. Hosted on Netlify as a static site; images are served through the Netlify Image CDN when hosted there and fall back to the plain files anywhere else.

## Run it locally

Open `index.html` in a browser, or serve the folder:

```bash
npx serve .          # or: netlify dev --port 8889
```

## Wiring it into the game

The menu never fakes matchmaking. It announces what the player chose and lets the game client take over:

```js
// Start the menu yourself if you replace the bundled splash:
window.dispatchEvent(new CustomEvent('viceheist:splash-complete'));

// Claim menu actions — call preventDefault() once the game handles it.
window.addEventListener('viceheist:menu-action', (e) => {
  const { action } = e.detail;          // 'quick-play' | 'create-lobby' | 'join-lobby'
  // create-lobby → { map, maxPlayers, visibility }   join-lobby → { code }
  e.preventDefault();
  startGame(e.detail);
});

// React to settings (also stored in localStorage under "viceheist.settings").
window.addEventListener('viceheist:settings-changed', (e) => applySettings(e.detail));
```

Until a game client claims an action, the menu shows a "lobbies open soon" notice.

## Download

`vice-heist-menu.zip` at the site root contains the complete menu (HTML, CSS, JS, images, fonts). Rebuild it after changes with `scripts/make-zip.sh`.

## What's left

- Connect `viceheist:menu-action` to the real game client / matchmaking.
- Replace the placeholder briefing copy, credits names and crew-size limits with the game's real values.
- Swap the synthesised menu music and effects for the game's own audio.
