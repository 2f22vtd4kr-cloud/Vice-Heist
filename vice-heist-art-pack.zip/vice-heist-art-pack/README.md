# Vice Heist art pack

This pack contains the supplied seven-color character art, extracted into transparent PNGs, plus a coordinated set of scalable UI button assets.

## Character atlas
- `characters/vice-creatures-atlas.png`: 7 columns (color variants) × 7 rows (poses), 160 × 160 pixels per frame.
- Rows, top to bottom: `idle`, `run_a`, `run_b`, `walk`, `ghost`, `seated`, `crouch`.
- Columns, left to right: `teal`, `red`, `blue`, `purple`, `brown`, `charcoal`, `pink`.
- Atlas is row-major: frame index = `poseRow * 7 + colorColumn`.
- Individual transparent frames are in `characters/individual/`.
- `characters/atlas-preview.jpg` is a quick visual reference.
- Original supplied sheet is retained in `source/original-character-sheet.png`.

## Suggested Phaser integration
Load the atlas with frame dimensions 160 × 160:
```ts
this.load.spritesheet('vice-creatures', '/assets/characters/vice-creatures-atlas.png', {
  frameWidth: 160,
  frameHeight: 160
});
```
Choose the column by player color and use that same column across pose rows. Suggested color-to-column mapping for the current server palette:
- `#58c99b`, `#6dd4d0` → 0 (teal)
- `#f45b5b` → 1 (red)
- `#54b7f2` → 2 (blue)
- `#a98af5` → 3 (purple)
- `#f0bd4b`, `#e78b4e`, `#b6cf5b` → 4 (brown)
- `#e4e7ec` → 5 (charcoal)
- `#f18dc3` → 6 (pink)

Suggested starting animation rows: idle row 0; run rows 1–3; down/ghost row 4. The supplied poses are distinct illustrations rather than a perfectly continuous animation cycle, so use a restrained frame rate and test foot placement before increasing animation speed.

## Buttons
- `ui/buttons/*.svg` are transparent, scalable vector button surfaces.
- Matching PNG exports are provided for pipelines that prefer raster images.
- Assets intentionally contain no labels or icons: render accessible text/icons as HTML on top, so localization and dynamic labels remain crisp.
- Variants: primary, secondary, danger, success, warning, disabled, icon, wide, square.

## Installation
Copy the contents of this archive into the repository root, preserving folders. The assets will land under `assets/` in this pack. For the current app's public asset path, copy:
- `characters/vice-creatures-atlas.png` → `client/public/assets/characters/vice-creatures-atlas.png`
- `ui/buttons/` → `client/public/assets/ui/buttons/`

No existing assets are overwritten.
