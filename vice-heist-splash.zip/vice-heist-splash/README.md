# Vice Heist — Splash Screen

The opening screen for **Vice Heist**, a mobile (portrait) social-deduction heist game set at Ocean Drive Estate.

The screen shows the estate as a 3D waterfront scene at sunset — rooftop helipad, garage, neon lounge, vault, pool deck and speedboat dock, all derived from the game's top-down map — with the balaclava crew standing on the deck, a ghost drifting over the pool and one grey crew member sneaking towards the vault. A loading bar with heist-flavoured tips leads into a "Tap to start" prompt.

## Tech

- TanStack Start (React 19, Vite) deployed on Netlify
- Tailwind CSS 4 plus hand-written splash styles (`src/styles.css`, `.vh-*` classes)
- Netlify Image CDN for the backdrop and character sprites
- Google Fonts: Bowlby One, Yellowtail, Chakra Petch

## Art

- `public/img/estate.jpg` — the estate backdrop (no characters painted in)
- `public/img/crew/*.png` — character sprites cut directly from the original character sheet, so they match the game's design exactly

## Run locally

```bash
pnpm install
netlify dev   # serves the app with the Image CDN emulated
```

## Editing the scene

Character positions, sizes and loading tips live in `src/lib/splash.ts`.
