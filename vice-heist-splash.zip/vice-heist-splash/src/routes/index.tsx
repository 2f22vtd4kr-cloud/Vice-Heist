import { useEffect, useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'

import { CREW, LOADING_TIPS, img } from '@/lib/splash'

export const Route = createFileRoute('/')({
  component: Splash,
})

type Phase = 'loading' | 'ready' | 'entering'

function Splash() {
  const [progress, setProgress] = useState(0)
  const [phase, setPhase] = useState<Phase>('loading')

  // Simulated boot sequence: fills the bar, then hands over to "tap to start".
  useEffect(() => {
    if (phase !== 'loading') return
    const timer = setInterval(() => {
      setProgress((p) => Math.min(100, p + 3 + Math.random() * 9))
    }, 220)
    return () => clearInterval(timer)
  }, [phase])

  useEffect(() => {
    if (phase !== 'loading' || progress < 100) return
    const t = setTimeout(() => setPhase('ready'), 350)
    return () => clearTimeout(t)
  }, [progress, phase])

  const tip =
    LOADING_TIPS[
      Math.min(
        LOADING_TIPS.length - 1,
        Math.floor((progress / 100) * LOADING_TIPS.length),
      )
    ]

  const start = () => {
    if (phase === 'ready') setPhase('entering')
  }

  return (
    <main className="vh-viewport">
      <button
        type="button"
        className={`vh-phone vh-phase-${phase}`}
        onClick={start}
        aria-label={
          phase === 'ready' ? 'Tap to start Vice Heist' : 'Vice Heist'
        }
      >
        {/* 9:16 stage: backdrop + sprites share one coordinate space */}
        <div className="vh-stage">
          <img
            className="vh-backdrop"
            src={img('/img/estate.jpg', 1080)}
            srcSet={`${img('/img/estate.jpg', 720)} 720w, ${img('/img/estate.jpg', 1080)} 1080w, ${img('/img/estate.jpg', 1536)} 1536w`}
            sizes="(min-aspect-ratio: 9/16) 57vh, 100vw"
            alt="Ocean Drive Estate at sunset: a waterfront villa with a rooftop helipad, garage, neon lounge, vault, pool and speedboat dock"
            fetchPriority="high"
            draggable={false}
          />

          <div className="vh-pool-glow" aria-hidden="true" />
          {[
            [27.2, 23.0],
            [52.6, 24.6],
            [2.6, 26.3],
            [29.2, 28.5],
          ].map(([x, y], i) => (
            <span
              key={i}
              className="vh-beacon"
              style={{ left: `${x}%`, top: `${y}%`, animationDelay: `${i * 0.35}s` }}
              aria-hidden="true"
            />
          ))}

          {CREW.map((c) => (
            <div
              key={c.id}
              className={`vh-crew vh-crew-${c.kind}`}
              style={{
                left: `${c.x}%`,
                bottom: `${100 - c.feetY}%`,
                height: `${c.h}%`,
                zIndex: Math.round(c.feetY * 10),
                animationDelay:
                  c.kind === 'idle' ? `${Math.abs(c.delay) * 0.25}s` : undefined,
              }}
              aria-hidden="true"
            >
              <img
                src={img(`/img/crew/${c.sprite}.png`, 320)}
                alt=""
                draggable={false}
                style={{
                  transform: c.flip ? 'scaleX(-1)' : undefined,
                  animationDelay: `${c.delay}s`,
                }}
              />
            </div>
          ))}
        </div>

        <div className="vh-shade" aria-hidden="true" />
        <div className="vh-scanlines" aria-hidden="true" />

        <header className="vh-logo">
          <span className="vh-logo-kicker">A crew of thieves. One rat.</span>
          <h1>
            <span className="vh-logo-vice">Vice</span>
            <span className="vh-logo-heist">HEIST</span>
          </h1>
          <span className="vh-logo-place">
            <i /> Ocean Drive Estate <i />
          </span>
        </header>

        <footer className="vh-footer">
          {phase === 'loading' && (
            <div className="vh-loading" role="status">
              <div className="vh-tip">{tip}</div>
              <div className="vh-bar">
                <div className="vh-bar-fill" style={{ width: `${progress}%` }} />
              </div>
              <div className="vh-pct">{Math.round(progress)}%</div>
            </div>
          )}
          {phase === 'ready' && (
            <div className="vh-tap">
              <span>Tap to start</span>
            </div>
          )}
          {phase === 'entering' && (
            <div className="vh-entering" role="status">
              <strong>You&rsquo;re in.</strong>
              <span>The crew is assembling&hellip; lobby opens soon.</span>
            </div>
          )}
          <p className="vh-tagline">Trust no one. Take everything.</p>
          <p className="vh-version">v0.1 &middot; pre-alpha</p>
        </footer>

        <div className="vh-flash" aria-hidden="true" />
      </button>
    </main>
  )
}
