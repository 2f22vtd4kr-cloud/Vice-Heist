/**
 * Splash-screen scene data.
 *
 * Positions are percentages of the 9:16 stage (the backdrop image), so the
 * sprites stay glued to the artwork at every screen size. `x` is the sprite's
 * horizontal centre, `feetY` is where its feet touch the ground (from the top),
 * `h` is its height. Keep x roughly within 15–85 so nothing is cropped on
 * tall phones, where the stage is trimmed at the sides.
 */
export type CrewMember = {
  id: string
  sprite: string // file name in public/img/crew (cut from the character sheet)
  kind: 'idle' | 'sneak' | 'ghost'
  x: number
  feetY: number
  h: number
  flip?: boolean
  delay: number
}

export const CREW: CrewMember[] = [
  { id: 'purple', sprite: 'purple', kind: 'idle', x: 22, feetY: 66.5, h: 8.6, delay: -0.4 },
  { id: 'red', sprite: 'red', kind: 'idle', x: 32, feetY: 69.5, h: 9.8, delay: -1.1 },
  { id: 'teal', sprite: 'teal', kind: 'idle', x: 45, feetY: 72, h: 11.4, delay: 0 },
  { id: 'blue', sprite: 'blue', kind: 'idle', x: 62, feetY: 67.5, h: 9.2, flip: true, delay: -0.7 },
  { id: 'pink', sprite: 'pink', kind: 'idle', x: 78, feetY: 68, h: 8.6, flip: true, delay: -1.6 },
  // The rat: slinking off towards the vault while the crew poses.
  { id: 'grey', sprite: 'grey-sneak', kind: 'sneak', x: 47, feetY: 40.6, h: 4.6, delay: 0 },
  // Someone already didn't make it.
  { id: 'ghost', sprite: 'ghost', kind: 'ghost', x: 56, feetY: 51, h: 6.6, delay: 0 },
]

export const LOADING_TIPS = [
  'Casing the estate…',
  'Bribing the valet…',
  'Looping the security cameras…',
  'Cracking the vault…',
  'Fuelling the getaway boat…',
  'Checking who’s wearing a wire…',
]

/** Netlify Image CDN URL for a file in /public. */
export const img = (path: string, w: number) =>
  `/.netlify/images?url=${encodeURIComponent(path)}&w=${w}&fm=webp`
